<?php

namespace Pterodactyl\Http\Requests\Api\Application\Servers\Databases;

class ServerDatabaseWriteRequest extends GetServerDatabasesRequest
{
}
