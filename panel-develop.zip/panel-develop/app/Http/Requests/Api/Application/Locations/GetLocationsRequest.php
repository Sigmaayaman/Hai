<?php

namespace Pterodactyl\Http\Requests\Api\Application\Locations;

use Pterodactyl\Http\Requests\Api\Application\ApplicationApiRequest;

class GetLocationsRequest extends ApplicationApiRequest
{
}
