<?php

namespace Pterodactyl\Http\Requests\Api\Application\Users;

class GetUserRequest extends GetUsersRequest
{
}
