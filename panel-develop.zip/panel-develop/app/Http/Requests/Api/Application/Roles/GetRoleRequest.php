<?php

namespace Pterodactyl\Http\Requests\Api\Application\Roles;

class GetRoleRequest extends GetRolesRequest
{
}
