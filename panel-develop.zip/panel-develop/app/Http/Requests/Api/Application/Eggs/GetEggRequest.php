<?php

namespace Pterodactyl\Http\Requests\Api\Application\Eggs;

class GetEggRequest extends GetEggsRequest
{
}
