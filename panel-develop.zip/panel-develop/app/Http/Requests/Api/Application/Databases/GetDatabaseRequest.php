<?php

namespace Pterodactyl\Http\Requests\Api\Application\Databases;

class GetDatabaseRequest extends GetDatabasesRequest
{
}
