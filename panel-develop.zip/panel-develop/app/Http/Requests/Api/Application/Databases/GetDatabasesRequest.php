<?php

namespace Pterodactyl\Http\Requests\Api\Application\Databases;

use Pterodactyl\Http\Requests\Api\Application\ApplicationApiRequest;

class GetDatabasesRequest extends ApplicationApiRequest
{
}
